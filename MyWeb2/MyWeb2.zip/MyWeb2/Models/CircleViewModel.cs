﻿namespace MyWeb2.Models
{
    public class CircleViewModel
    {
        public double rr { get; set; }
        public double DienTich { get; set; }
        public double ChuVi { get; set; }
        public double DuongKinh { get; set; }
    }
}
