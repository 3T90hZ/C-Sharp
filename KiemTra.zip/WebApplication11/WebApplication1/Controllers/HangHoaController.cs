﻿using Microsoft.AspNetCore.Mvc;
using MyMvcApp.Models;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MyMvcApp.Controllers
{
    public class GoodsController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiBaseUrl = "http://localhost:5174/api/HangHoa"; // URL API của bạn

        public GoodsController()
        {
            _httpClient = new HttpClient();
        }

        // 🟢 HIỂN THỊ DANH SÁCH HÀNG HÓA (GET)
        public async Task<IActionResult> Index()
        {
            var response = await _httpClient.GetStringAsync(_apiBaseUrl);
            var goodsList = JsonSerializer.Deserialize<List<Goods>>(response, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            return View(goodsList);
        }

        // 🟢 FORM THÊM HÀNG HÓA
        public IActionResult Create() => View();

        // 🔴 XỬ LÝ THÊM HÀNG HÓA (POST)
        [HttpPost]
        public async Task<IActionResult> Create(Goods goods)
        {
            var jsonData = JsonSerializer.Serialize(goods);
            var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(_apiBaseUrl, content);
            if (response.IsSuccessStatusCode)
                return RedirectToAction("Index");

            return View(goods);
        }

        // 🟢 FORM CẬP NHẬT HÀNG HÓA
        public async Task<IActionResult> Edit(int id)
        {
            var response = await _httpClient.GetStringAsync($"{_apiBaseUrl}/{id}");
            var goods = JsonSerializer.Deserialize<Goods>(response, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            return View(goods);
        }

        // 🔴 XỬ LÝ CẬP NHẬT HÀNG HÓA (POST)
        [HttpPost]
        public async Task<IActionResult> Edit(Goods goods)
        {
            var jsonData = JsonSerializer.Serialize(goods);
            var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

            var response = await _httpClient.PutAsync($"{_apiBaseUrl}/{goods.MaHangHoa}", content);
            if (response.IsSuccessStatusCode)
                return RedirectToAction("Index");

            return View(goods);
        }

        // 🟢 FORM XÓA HÀNG HÓA
        public async Task<IActionResult> Delete(int id)
        {
            var response = await _httpClient.GetStringAsync($"{_apiBaseUrl}/{id}");
            var goods = JsonSerializer.Deserialize<Goods>(response, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            return View(goods);
        }

        // 🔴 XỬ LÝ XÓA HÀNG HÓA (POST)
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"{_apiBaseUrl}/{id}");
            if (response.IsSuccessStatusCode)
                return RedirectToAction("Index");

            return RedirectToAction("Index");
        }
    }
}
