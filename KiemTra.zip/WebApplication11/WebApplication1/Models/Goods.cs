﻿namespace MyMvcApp.Models
{
    public class Goods
    {
        public int MaHangHoa { get; set; }
        public string TenHangHoa { get; set; }
        public int SoLuong { get; set; }
        public string GhiChu { get; set; } // Cột mới
    }
}
