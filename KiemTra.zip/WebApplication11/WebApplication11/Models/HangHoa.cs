﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SetupDatabaseAPI.Models
{
    [Table("Goods")]
    public class HangHoa
    {
        [Key]
        [StringLength(9)]
        public string MaHangHoa { get; set; } = null!;

        [Required]
        [Column(TypeName = "nvarchar(MAX)")]
        public string TenHangHoa { get; set; } = null!;

        public int SoLuong { get; set; }
        public string? GhiChu { get; set; } // Cột mới
    }
}
